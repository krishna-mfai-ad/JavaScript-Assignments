var fname=document.getElementById("firstName").value
var fnameRes=document.getElementById("firstNamePara")

var lname=document.getElementById("lastName").value
var lnameRes=document.getElementById("lastNamePara")

var email=document.getElementById("email").value
var emailRes=document.getElementById("emailPara")

var pass=document.getElementById("password").value
var passRes=document.getElementById("passwordPara")

/*Password and username should not same
Username should contain atleast 4 characters 
Password should contain minimum 6 and maximum 16 characters 
Password should contain atleast 1 uppercase
Password should contain atleast 1 lowercase
Password should contain atleast 1 number
Password should contain atleast 1 special characters */

function check()
{
    if(fname.length==0 || fname.length<4){
        fnameRes.textContent="Invalid Username"
    }
    else{
        fnameRes.textContent="AcceptedUsername"
    }
}
// Length Not Working?