var One = document.getElementById("one")
var Two = document.getElementById("two")
var Three = document.getElementById("three")
var Four = document.getElementById("four")
var Five = document.getElementById("five")

var btn = document.getElementById("submitBtn")
var rated = "OFF"

function one1() {
    if (rated == "OFF") {
        One.style = "color:white; background: hsl(25, 97%, 53%);"
        rated = "ON"
        var count=1
    }
    else if (rated = "ON") {
        rated = "OFF"
        One.style = "color: grey; background: hsl(218, 21 %, 23 %); "
    }
}
function two2() {
    if (rated == "OFF") {
        Two.style = "color:white; background: hsl(25, 97%, 53%);"
        rated = "ON"
        var count=2
    }
    else if (rated = "ON") {
        rated = "OFF"
        Two.style = "color: grey; background: hsl(218, 21 %, 23 %); "
    }
}
function three3() {
    if (rated == "OFF") {
        Three.style = "color:white; background: hsl(25, 97%, 53%);"
        rated = "ON"
        var count=3
    }
    else if (rated = "ON") {
        rated = "OFF"
        Three.style = "color: grey; background: hsl(218, 21 %, 23 %); "
    }
}
function fou() {
    if (rated == "OFF") {
        Four.style = "color:white; background: hsl(25, 97%, 53%);"
        rated = "ON"
        var count=4
    }
    else if (rated = "ON") {
        rated = "OFF"
        Four.style = "color: grey; background: hsl(218, 21 %, 23 %); "
    }
}
function fiv() {
    if (rated == "OFF") {
        Five.style = "color:white; background: hsl(25, 97%, 53%);"
        rated = "ON"
        var count=5
    }
    else if (rated = "ON") {
        rated = "OFF"
        Five.style = "color: grey; background: hsl(218, 21 %, 23 %); "
    }
}
    
function sub() {
    if(rated=="OFF"){
        btn.style = "color:white; background: hsl(218, 21 %, 23 %);"
    
    }
    if(rated=="ON"){
        let a="thankyou.html"
        btn.style = "color:orange; background: white;"
        window.location.assign(a);
    }
}
